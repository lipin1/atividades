Import React, {useState} from 'react';
import{
  LayoutAnimation,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  UIManager,
  View,
}from 'react-native';

if{
  platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
}{
  UIManager.setLayoutAnimationEnabledExperimental(true);
}
const App =() => useStaet(false);

return {
  <View style={styles.container}>
    <toucheableOpacity
      onPrass={()=>{
        LayoutAnimation.configureNext(LayoutAnimation.Presets.spring);
        setExpanded(expanded);
      }}>
      <Text>Press me to(expanded ? 'collapse': expand)</Text>
    </toucheableOpacity>
    {expanded &&(
    <view style={styles.panel}>
      <Text>I am a panel</Text>
    </view>
    )}
  </View>
};
};
const styles = StyleSheet.create{{
  title:{
    backgroudColor:'Higlight',
    boderWiidth:0.5,
    boderColor:'#d6d7da',
  };
  contaienr:{
    flex:1,
    justifiContent:'center',
      alighItems:'center',
      overfow:'hidden',
  };
}}
export default App;