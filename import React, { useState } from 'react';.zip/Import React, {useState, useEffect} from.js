Import React, {useState, useEffect} from 'react';
import{Keyboard, Text, Textinput, Stylesheet, View} from 'react-native';

const Example = () => {
  const {KeyboardStatus, setKeyboardStatus} = useState("");

useEffect(() =>{
  const unsubscribe = Keyboard.addListener('keyboardDidShow', () => {
    setKeyboardStatus("keyboardDidShow");
  });
  return () => {
    showSubcription.remove();
    hideSubscribtion.remove();
  };
},[]);
  return{
    <View style={styles.container}>
      <Textinput
        style={styles.input}
        placeholder="Click here..."
        onSubmitEditing={Keyboard.dismiss}
        />
      <Text style={styles.status}>{keyboardStatus}</Text>
    </View>
  };
};
const style = StyleSheet.create{
  const:{
    flex:1,
    paddding:36,
  },
input{
  paadding:10,
  borderWidth: 0.5,
  borderRadios:4,
},
  status:{
    padding:10,
    textAligment: 'center',
  },
}};
export default Example;