import React, { useState } from 'react';
import {Alert, Button, Liking, StyleSheet, View} from 'react-native';

const supportedURL = 'https://google.com';

const unsupportedURL = 'slack://open?lear=123456';

type OpenURLButtonProps = {
  url: string;
  children: string;
};

const OpenURLButton = ({url, children}: OpenURLButtonProps) =>{
  const handlePress = useCallback(async () =>{
    //Checking if the link supported for links with custom URL schemes
    const supported = await Linking.canOpenURL(url);

    if(supported){
      //Opening the link with some app, if the URL scheme is "http" the web link shoud be opened
      //by some browser in the mobile
      await Linking.openURL(url);
      Linking.openURL(url);
    }else{
      Alert.alert "Don't know how to open this URL:$(url)");
    }
  }(url);
  return<Button title={children} onPress={handlePress}/>;                        
};
const App = () =>{
  return(
    <View style={styles.container}>
      <OpenURLButton url={supportedURL} children="Open supported URL"/>
      <OpenURLButton url={unsupportedURL} children="Open unsupported URL"/>
    </View>
  );
};
const styles = StyleSheet.create{function (container: {
  flex: 1;
  justifyContent: 'center';
  alignItems: 'center';
}) void 0}
export default App;